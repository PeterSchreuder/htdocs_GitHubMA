module.exports = {
  extends: [
    'ryansobol/es5',
    'ryansobol/node'
  ]
};
